﻿DataCzas today = DataCzas.Today;

Console.WriteLine(today.ToString("dd/MM/yyyy"));